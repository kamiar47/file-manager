package com.hoshmandsakht.efm;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.util.Stack;

public class utils {


    public static class one_threaded_task_handler{
        private Thread thread;
        public static interface task_interface{
            public boolean is_still_relevant(int id);
            public void on_task_done(int id);
        }
        public class task{
            public int id;
            public Runnable runnable;
            public task_interface task_interface;
            public task(Runnable runnable,int id,task_interface ti){
                this.id=id;
                this.runnable=runnable;
                this.task_interface=ti;
            }
        }
        private volatile Stack<task> tasks=new Stack<>();
        public void add_task(Runnable runnable,int id,task_interface ti){
            synchronized (tasks){
                tasks.push(new task(runnable,id,ti));
                tasks.notifyAll();
            }
        }
        public one_threaded_task_handler(){
            thread=new Thread(new Runnable() {
                @Override
                public void run() {
                    synchronized (tasks){
                        while(!is_halted){
                            try {
                                if (tasks.isEmpty()) {
                                    try {
                                        tasks.wait();
                                    } catch (InterruptedException e) {
                                        break;
                                    }
                                } else {
                                    task t = tasks.pop();
                                    if (t.task_interface.is_still_relevant(t.id)) {
                                        try {
                                            t.runnable.run();
                                        } catch (Throwable th) {

                                        }
                                    }
                                    t.task_interface.on_task_done(t.id);
                                }
                            }catch (Throwable t){
                                t.printStackTrace();
                            }
                        }
                    }
                }
            });
            thread.start();

        }
        private boolean is_halted;
        public void halt(){
            this.is_halted=true;
            thread.interrupt();
        }
        public void vanish_all_tasks(){
            tasks.removeAllElements();
        }
    }

    public static class image_utils{
        public static class memory_considering_bitmap {
            public static Bitmap loadLightWeightBitmap(byte[] imageByteArray) {
                return decodeBitmap(imageByteArray, 1); // Adjust the sampleSize for lighter weight
            }
            public static Bitmap loadHighQualityBitmap(byte[] imageByteArray) {
                return decodeBitmap(imageByteArray, 4); // Adjust the sampleSize for higher quality
            }
            public static Bitmap loadLightWeightBitmap(File src) {
                return decodeBitmap(src, 1); // Adjust the sampleSize for lighter weight
            }
            public static Bitmap loadHighQualityBitmap(File src) {
                return decodeBitmap(src, 4); // Adjust the sampleSize for higher quality
            }
            public static Bitmap decodeBitmap(byte[] imageByteArray, int sampleSize) {
                Bitmap bitmap = null;
                try {

                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inSampleSize = sampleSize; // Set the sampleSize to downscale the image

                    // Decode the bitmap using BitmapFactory
                    bitmap = BitmapFactory.decodeByteArray(imageByteArray,0,imageByteArray.length, options);

                } catch (Exception e) {
                    Log.e("ImageLoader", "Error loading bitmap: " + e.getMessage());
                }
                return bitmap;
            }

            public static Bitmap decodeBitmap(File src, int sampleSize) {
                Bitmap bitmap = null;
                try {

                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inSampleSize = sampleSize; // Set the sampleSize to downscale the image

                    // Decode the bitmap using BitmapFactory
                    bitmap = BitmapFactory.decodeFile(src.getAbsolutePath(), options);

                } catch (Exception e) {
                    Log.e("ImageLoader", "Error loading bitmap: " + e.getMessage());
                }
                return bitmap;
            }
        }
    }

    public static void delete_file(File fileOrFolder) {
        Stack<File> stack = new Stack<>();
        stack.push(fileOrFolder);
        while (!stack.isEmpty()) {
            File currentFile = stack.pop();
            if (currentFile.isDirectory()) {
                File[] files = currentFile.listFiles();
                if(files.length!=0)
                    stack.push(currentFile);//delete after all subdirectories are deleted
                if (files != null) {
                    for (File file : files) {
                        stack.push(file);
                    }
                }
            }
            if (!currentFile.delete()) {
                try {
                    Runtime.getRuntime().exec("/bin/rm " + currentFile.getAbsolutePath()).waitFor();
                } catch (IOException e) {
//                    throw new RuntimeException(e);
                } catch (InterruptedException e) {
//                    throw new RuntimeException(e);
                }
                // Handle deletion failure if needed
//                System.out.println("Failed to delete: " + currentFile.getAbsolutePath());
            }
        }
        if(fileOrFolder.isDirectory()) {
            try {
                Runtime.getRuntime().exec("/bin/rm -r" + fileOrFolder.getAbsolutePath());
            } catch (IOException e) {
//            throw new RuntimeException(e);
            }
        }
    }
    public static void copy_files(File src,File dst) throws IOException {
        if(!dst.exists()){
            dst.mkdirs();
        }
        if(!dst.exists()){
            dst.mkdir();
        }
        String cmd="cp ";
        if(src.isDirectory())
            cmd=cmd+"-R ";
        Runtime.getRuntime().exec(cmd+src.getAbsolutePath()+" "+dst.getAbsolutePath());
    }
    public static void move_files(File src,File dst) throws IOException {
        if(!dst.exists()){
            dst.mkdirs();
        }
        if(!dst.exists()){
            dst.mkdir();
        }
        String cmd="mv ";
        Runtime.getRuntime().exec(cmd+src.getAbsolutePath()+" "+dst.getAbsolutePath());
    }
    public static void copy_file(File src,File dst) throws IOException, InterruptedException {
        if(!dst.getParentFile().exists()){
            dst.mkdirs();
        }
        if(!dst.getParentFile().exists()){
            dst.mkdir();
        }
        String cmd="cp ";
        Runtime.getRuntime().exec(cmd+src.getAbsolutePath()+" "+dst.getAbsolutePath());
    }
}
