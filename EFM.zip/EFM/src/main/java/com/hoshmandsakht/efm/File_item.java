package com.hoshmandsakht.efm;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.File;

public class File_item {
  public String FileName;
  
  public String File_parent_path;
  
  public Bitmap File_image_bitmap;
  
  public boolean is_selected = false;
  
  public File_item(String FileName, String file_parent_path) {
    this.FileName = FileName;
    this.File_parent_path = file_parent_path;
  }
  
  public void switch_selection_status() {
    this.is_selected = !this.is_selected;
  }
  
  public void load_image_bitmap() {
    File f = new File(this.File_parent_path + "/" + this.FileName);
    String type = easyFileManager.getFileType(f);
    if (type != null) {
      if (!type.contains("image"))
        return; 
    } else {
      return;
    } 
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inJustDecodeBounds = true;
    BitmapFactory.decodeFile(this.File_parent_path + "/" + this.FileName, options);
    options.inSampleSize = easyFileManager.calculateInSampleSize(options, 60, 60);
    options.inJustDecodeBounds = false;
    this.File_image_bitmap = BitmapFactory.decodeFile(this.File_parent_path + "/" + this.FileName, options);
  }
}
