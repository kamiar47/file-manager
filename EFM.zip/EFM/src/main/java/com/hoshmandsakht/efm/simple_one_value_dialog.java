package com.hoshmandsakht.efm;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.hoshmandsakht.efm.R;

public class simple_one_value_dialog {
    public interface simple_one_value_dialog_interface{
        public void on_value_submitted(String value);
    }
    public static void input(Context context,simple_one_value_dialog_interface sovdi,String value_name,String button_value,String on_empty_error_text) {
        final Dialog dialog = new Dialog(context);
        dialog.show();
        dialog.getWindow().addFlags(1);
        dialog.getWindow().setLayout(-1, -2);
        dialog.setContentView(R.layout.input_one_value_layout);
        ((Button)dialog.findViewById(R.id.input_butt_id)).setText(button_value);
        ((EditText)dialog.findViewById(R.id.value_id)).setHint(value_name);
        ((EditText)dialog.findViewById(R.id.value_id)).setText("");

        dialog.findViewById(R.id.input_butt_id).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String value = ((EditText)dialog.findViewById(R.id.value_id)).getText().toString();
                if (value.length() > 0) {
                    sovdi.on_value_submitted(value);
                    dialog.dismiss();
                } else {
                    if(on_empty_error_text!=null){
                        Toast.makeText(context, on_empty_error_text, Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
