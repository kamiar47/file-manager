package com.hoshmandsakht.efm;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

public class easyFileManager extends Fragment {
    public static final int MODE_SINGLE_FILE_SELECTION = 1001;
    public static final int MODE_REGULAR_FILE_MANAGMENT = 1002;
    public static final String OPTION_DELETE_ID = "DEL";
    public static final String OPTION_COPY_ID = "CPY";
    public static final String OPTION_MOVE_ID = "MV";
    public static final String OPTION_SHARE_ID = "SHARE";
    public static final String OPTION_PASTE_ID = "PASTE";
    public static final String OPTION_NEW_FOLDER_ID = "NEW_FOLDER";
    public static final String OPTION_NEW_FILE_ID = "NEW_FILE";
    public static final String OPTION_SWITCH_VIEW = "SV";
    public static final int STATE_BROWSING_DIRS_TO_SELECT_COPY_OR_CUT_DESTINATION = 1;
    public static final int STATE_BROWSING_DIRS = 0;
    public static final byte VIEW_MODE_GRID = 0, VIEW_MODE_LIST = 1;
    private static final int Count_of_images_to_be_loaded_for_future_use = 80;
    private final List<File_item> current_directory_FileItem_list = new ArrayList<>();
    private final List<File_item> current_directory_FileItem_list_tmp = new ArrayList<>();
    private final Context context;
    private final Activity parent_activity;
    private View optionsBar_scroolview;
    private final List<Option_item> option_items_list = new ArrayList<>();
    private final List<extention_icon> icons_and_extentions_list = new ArrayList<>();
    private final utils.one_threaded_task_handler image_loader = new utils.one_threaded_task_handler();
    private final List<File> fileList = new ArrayList<>();
    public String SDCARD_Path = "/sdcard";
    public int state = 0;
    public boolean FileManager_is_ready = false;
    public List<String> allowed_file_extentions_list = new ArrayList<>();
    public List<String> excluded_file_extentions_list = new ArrayList<>();
    public List<String> allowed_folder_extentions_list = new ArrayList<>();
    public List<String> excluded_folder_extentions_list = new ArrayList<>();
    private int mode_2_pos;
    private String Option_id_being_carried_out = "";
    private String current_directory_path = "/sdcard/", current_directory_path_tmp = "";
    private String tmpaddr0 = "/";
    private byte view_mode;
    private RecyclerView recyclerView;
    private RecyclerView gridView;
    private fileadapter adap;
    private grid_fileadapter grid_adap;
    private int s_s = 0;
    private int mode;
    private int s_s_tmp;
    private boolean filemanager_exited = false;
    private boolean options_bar_is_visible = true;
    private TextView path;
    private Button paste_button;
    private CountDownTimer dataset_refresher;
    private RecyclerView.LayoutManager layoutManager;
    private GridLayoutManager gridLayoutManager;
    private ConstraintLayout main_layout;
    private LinearLayout options_bar;
    private FileManager_states_listener fileManager_states_listener;
    private File_item_evens_listener file_item_events_listener;
    private int last_s_s = -1;

    public easyFileManager() {
        this.parent_activity = getActivity();
        this.context = (Context) this.parent_activity;
    }

    public easyFileManager(Activity activity, String directory_to_browse, int mode, byte view_mode,
                           FileManager_states_listener fileManager_states_listener) throws Exception {
        if (Build.VERSION.SDK_INT >= 23) {
            if (activity.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED)
                throw new Exception("Permission Denied. check READ_EXTERNAL_STORAGE permission before creating this object.");
        } else if (Environment.getExternalStorageDirectory().list() != null) {
            if ((Environment.getExternalStorageDirectory().list()).length < 1)
                throw new Exception("Permission Denied. check READ_EXTERNAL_STORAGE permission before creating this object.");
        } else {
            throw new Exception("Permission Denied. check READ_EXTERNAL_STORAGE permission before creating this object.");
        }
        if (mode != MODE_REGULAR_FILE_MANAGMENT && mode != MODE_SINGLE_FILE_SELECTION)
            throw new Exception("No such mode.");
        this.parent_activity = activity;
        this.current_directory_path = directory_to_browse;
        this.mode = mode;
        this.view_mode = view_mode;
        this.context = (Context) activity;
        this.fileManager_states_listener = fileManager_states_listener;
    }

    public static String getFileType(File file) {
        String type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(get_FileName_Extention(file.getName()));
        if (type == null)
            return " ";
        return type;
    }

    public static String get_FileName_Extention_full(String filename) {
        if (filename == null || filename.isEmpty()) {
            return "";
        }
        int dotIndex = filename.indexOf(".");
        if (dotIndex == -1) {
            return "";
        }
        String ret = filename.substring(dotIndex + 1);
        return ret;
    }

    public static String get_FileName_without_Extention(String filename) {
        if (filename == null || filename.isEmpty()) {
            return "";
        }
        int dotIndex = filename.indexOf(".");
        if (dotIndex == -1) {
            return filename;
        }
        String ret = filename.substring(0, dotIndex);
        return ret;
    }

    public static String get_FileName_Extention(String filename) {
        if (filename == null || filename.isEmpty()) {
            return "";
        }
        int dotIndex = filename.lastIndexOf(".");
        if (dotIndex == -1) {
            return "";
        }
        String ret = filename.substring(dotIndex + 1);
        return ret;
    }

    public static File return_nonexisting_file(String dir, String name, String ext) {
        int i = 0;
        File otmp1 = new File(dir + name + ext);
        while (otmp1.exists()) {
            i++;
            otmp1 = new File(dir + add_num_to_name(name, i) + ext);
        }
        return otmp1;
    }

    public static String add_num_to_name(String name, int i1) {
        int i = 0;
        while (i < (name.toCharArray()).length &&
                name.charAt(i) != '.')
            i++;
        String n = String.valueOf(name.toCharArray(), 0, i);
        name = n + "_" + i1 + String.copyValueOf(name.toCharArray(), i, name.length() - i);
        return name;
    }

    public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        int height = options.outHeight;
        int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            int halfHeight = height / 2;
            int halfWidth = width / 2;
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth)
                inSampleSize *= 2;
        }
        return inSampleSize;
    }

    public static void perform_action_on_file_or_folder(File Folder_or_File, File_action_event_listener action) throws Throwable {
        action.on_File_about_to_be_processed(Folder_or_File);
        if (Folder_or_File.isDirectory()) {
            String root_dir = Folder_or_File.getPath() + "/";
            List<String> last_dir = new ArrayList<>();
            last_dir.add(root_dir);
            List<folder_struc> f = new ArrayList<>();
            f.add(new folder_struc(Folder_or_File.list()));
            action.on_Overall_progress_changed(0, ((folder_struc) f.get(0)).lenght);
            int p = 0;
            folder_struc tmp = f.get(p);
            while (tmp.pointer <= tmp.lenght) {
                if (tmp.pointer == tmp.lenght) {
                    f.remove(p);
                    if (p > 0) {
                        p--;
                        tmp = f.get(p);
                        root_dir = root_dir.substring(0, root_dir.length() - ((String) last_dir.get(p + 1)).length() - 1) + "/";
                        last_dir.remove(p + 1);
                        continue;
                    }
                    break;
                }
                File fi = new File(root_dir + tmp.list[tmp.pointer]);
                tmp.pointer++;
                action.on_File_about_to_be_processed(fi);
                if (fi.isFile()) ;
                if (fi.isDirectory()) {
                    p++;
                    last_dir.add(fi.getName() + "/");
                    root_dir = root_dir + (String) last_dir.get(p);
                    f.add(new folder_struc(fi.list()));
                    tmp = f.get(p);
                }
                if (p == 0)
                    action.on_Overall_progress_changed(tmp.pointer, tmp.lenght);
            }
            action.on_Overall_progress_changed(tmp.lenght, tmp.lenght);
        }
        if (Folder_or_File.isFile()) {
            action.on_File_about_to_be_processed(Folder_or_File);
            action.on_Overall_progress_changed(1, 1);
        }
    }

    public static void processFolderIterative(File file_folder, File_action_event_listener action) throws Throwable {
        if (file_folder.isFile()) {

            action.on_File_about_to_be_processed(file_folder);
            return; // Ignore non-directories
        }
        if (!file_folder.isDirectory())
            return;
        Stack<File> foldersToProcess = new Stack<>();
        foldersToProcess.push(file_folder);

        while (!foldersToProcess.isEmpty()) {
            File currentFolder = foldersToProcess.pop();
            action.on_File_about_to_be_processed(currentFolder);

            File[] files = currentFolder.listFiles();
            for (File file : files) {
                if (file.isDirectory()) {
                    foldersToProcess.push(file); // Add sub-directories to the stack
                } else {
                    action.on_File_about_to_be_processed(file);
                }
            }
        }
    }

    private boolean list_contains(List list, String item) {
        int i = 0;
        while (i < list.size()) {
            if (((String) list.get(i)).equals(item))
                return true;
            i++;
        }
        return false;
    }

    public void make_option_blink(String Option_id) {
        for (Option_item item : option_items_list) {
            if (item.Option_id.equals(Option_id)) {
                item.make_icon_blink();
                return;
            }
        }
    }

    public void add_on_FileItem_EventListener(File_item_evens_listener file_item_evens_listener) {
        this.file_item_events_listener = file_item_evens_listener;
    }

    public void add_Icon_for_file_type(Bitmap icon, String File_Extention) {
        this.icons_and_extentions_list.add(new extention_icon(icon, File_Extention));
        if (this.adap != null)
            this.notify_relative_adapter();
    }

    public void add_Icon_for_file_type(Drawable icon, String File_Extention) {
        this.icons_and_extentions_list.add(new extention_icon(icon, File_Extention));
        if (this.adap != null)
            this.notify_relative_adapter();
    }

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        this.main_layout = (ConstraintLayout) inflater.inflate(R.layout.filemanager_main, container, false);
        this.recyclerView = (RecyclerView) this.main_layout.findViewById(R.id.recycv);
        this.options_bar = (LinearLayout) this.main_layout.findViewById(R.id.options_id);
        this.optionsBar_scroolview =this.main_layout.findViewById(R.id.options_scrollview_id);

        this.layoutManager = (RecyclerView.LayoutManager) new LinearLayoutManager(this.context);
        this.recyclerView.setLayoutManager(this.layoutManager);

        this.gridView = (RecyclerView) this.main_layout.findViewById(R.id.grid_view);
        this.gridLayoutManager = new GridLayoutManager(this.parent_activity, 3);
        this.gridView.setLayoutManager(this.gridLayoutManager);

        this.path = (TextView) this.main_layout.findViewById(R.id.path);
        this.paste_button = (Button) this.main_layout.findViewById(R.id.paste);
        if (this.mode == MODE_SINGLE_FILE_SELECTION)
            this.options_bar_is_visible = false;
        show_OptionsBar(this.options_bar_is_visible);
        load_directory_files(new File(this.current_directory_path), false);
        this.adap = new fileadapter();
        this.recyclerView.setAdapter(this.adap);
        this.grid_adap = new grid_fileadapter();
        this.gridView.setAdapter(this.grid_adap);
        set_view_mode(view_mode);
        this.notify_relative_adapter();
        this.dataset_refresher = (new CountDownTimer(Long.MAX_VALUE, 1910L) {
            public void onTick(long l) {
                easyFileManager.this.notify_relative_adapter();
            }

            public void onFinish() {
            }
        }).start();
        UI_config.option_icon.Option_icon_height =
                UI_config.option_icon.Option_icon_width =
                        (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 55.0F, this.context

                                .getResources().getDisplayMetrics());
        this.FileManager_is_ready = true;
        this.fileManager_states_listener.onFile_Manager_Ready(this);
        return (View) this.main_layout;
    }

    private void notify_relative_adapter() {
        if (view_mode == VIEW_MODE_LIST) {
            this.adap.notifyDataSetChanged();
        }
        if (view_mode == VIEW_MODE_GRID) {
            this.grid_adap.notifyDataSetChanged();
        }
    }

    public void set_view_mode(byte view_mode) {
        this.view_mode = view_mode;
        if (view_mode == VIEW_MODE_LIST) {
            this.main_layout.setBackgroundResource(R.color.filemanager_list_background);
            this.recyclerView.setVisibility(View.VISIBLE);
            this.gridView.setVisibility(View.GONE);
//      image_loader.vanish_all_tasks();
        }
        if (view_mode == VIEW_MODE_GRID) {
            this.main_layout.setBackgroundResource(R.color.filemanager_grid_background);
            this.recyclerView.setVisibility(View.GONE);
            this.gridView.setVisibility(View.VISIBLE);
//      image_loader.vanish_all_tasks();
        }
        notify_relative_adapter();
    }

    public void add_common_options_and_operations() {
        try {
            add_Option_to_OptionsBar(R.drawable.view_grid
                    , new Option_item_events_listener() {
                        public void Option_item_OnClickListener(List<File> selected_Files_list) {
                            try {
                                if (easyFileManager.this.view_mode == VIEW_MODE_LIST) {
                                    easyFileManager.this.set_view_mode(VIEW_MODE_GRID);
                                    Option_item item = get_option_by_optionID(OPTION_SWITCH_VIEW);
                                    if (item != null) {
                                        item.button.setImageDrawable(parent_activity.getResources().getDrawable(R.drawable.view_list));
                                    }
                                } else if (easyFileManager.this.view_mode == VIEW_MODE_GRID) {
                                    easyFileManager.this.set_view_mode(VIEW_MODE_LIST);
                                    Option_item item = get_option_by_optionID(OPTION_SWITCH_VIEW);
                                    if (item != null) {
                                        item.button.setImageDrawable(parent_activity.getResources().getDrawable(R.drawable.view_grid));
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }

                        public void Option_item_OnlongClickListener(List<File> selected_Files_list) {
                            Toast.makeText(easyFileManager.this.context, "change list layout", Toast.LENGTH_LONG).show();
                        }
                    }, OPTION_SWITCH_VIEW, false, false);
            add_Option_to_OptionsBar(R.drawable.folder_plus_outline, new Option_item_events_listener() {
                public void Option_item_OnClickListener(List<File> selected_Files_list) {
                    try {
                        easyFileManager.this.add_folder();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                public void Option_item_OnlongClickListener(List<File> selected_Files_list) {
                    Toast.makeText(easyFileManager.this.context, "new folder", Toast.LENGTH_LONG).show();
                }
            }, "NEW_FOLDER", false, false);
            add_Option_to_OptionsBar(R.drawable.content_copy, new Option_item_events_listener() {
                public void Option_item_OnClickListener(List<File> selected_Files_list) {
                    easyFileManager.this.set_state(1);
                    easyFileManager.this.Option_id_being_carried_out = "CPY";
                    easyFileManager.this.paste_button.setText("copy here");
                }

                public void Option_item_OnlongClickListener(List<File> selected_Files_list) {
                    Toast.makeText(easyFileManager.this.context, "copy", Toast.LENGTH_LONG).show();
                }
            }, "CPY", true, false);
            add_Option_to_OptionsBar(R.drawable.content_cut, new Option_item_events_listener() {
                public void Option_item_OnClickListener(List<File> selected_Files_list) {
                    easyFileManager.this.set_state(1);
                    easyFileManager.this.Option_id_being_carried_out = "MV";
                    easyFileManager.this.paste_button.setText("move here");
                }

                public void Option_item_OnlongClickListener(List<File> selected_Files_list) {
                    Toast.makeText(easyFileManager.this.context, "cut", Toast.LENGTH_LONG).show();
                }
            }, "MV", true, false);
            add_Option_to_OptionsBar(R.drawable.delete_forever, new Option_item_events_listener() {
                public void Option_item_OnClickListener(List<File> selected_Files_list) {
                    yes_no_dialog.input(parent_activity, new yes_no_dialog.simple_yes_no_interface() {
                        @Override
                        public void on_value_submitted(boolean decision) {
                            if (decision) {
                                for (File_item file_item : (easyFileManager.this.state == STATE_BROWSING_DIRS) ? easyFileManager.this.current_directory_FileItem_list : easyFileManager.this.current_directory_FileItem_list_tmp) {
                                    if (file_item.is_selected) {
                                        utils.delete_file(new File(file_item.File_parent_path + "/" + file_item.FileName));
                                    }
                                }
//                easyFileManager.this.load_directory_files(new File((easyFileManager.this.state == STATE_BROWSING_DIRS) ? easyFileManager.this.current_directory_path : easyFileManager.this.current_directory_path_tmp), false);
//                Toast.makeText(easyFileManager.this.context, "Files deleted", Toast.LENGTH_LONG).show();
                            } else {
                                //nothing happens
                            }
                        }
                    }, getString(R.string.delete_exp), "proceed", "cancel");
//          for (File_item file_item : (easyFileManager.this.state == STATE_BROWSING_DIRS) ? easyFileManager.this.current_directory_FileItem_list : easyFileManager.this.current_directory_FileItem_list_tmp) {
//            if (file_item.is_selected) {
//              utils.delete_file(new File(file_item.File_parent_path + "/" + file_item.FileName));
//            }
//          }
//          easyFileManager.this.load_directory_files(new File((easyFileManager.this.state == STATE_BROWSING_DIRS) ? easyFileManager.this.current_directory_path : easyFileManager.this.current_directory_path_tmp), false);
//          Toast.makeText(easyFileManager.this.context, "Files deleted", Toast.LENGTH_LONG).show();
                }

                public void Option_item_OnlongClickListener(List<File> selected_Files_list) {
                    Toast.makeText(easyFileManager.this.context, "delete", Toast.LENGTH_LONG).show();
                }
            }, OPTION_DELETE_ID, true, false);
            add_Option_to_OptionsBar(
                    R.drawable.share_variant,
                    new Option_item_events_listener_with_processor() {
                        @Override
                        public boolean check_file_list(List<File> files) {
                            for (File file : files)
                                if (file.isDirectory()) return false;
                            return true;
                        }

                        @Override
                        public void Option_item_OnClickListener(List<File> paramList) {
                            if (s_s > 0) {
                                int i = 0;
                                ArrayList<Uri> uri = new ArrayList<>();
                                List<File> selected = get_selected_Files_list();
                                while (i < s_s) {
                                    if (selected.get(i).isDirectory()) {
                                        Toast.makeText(parent_activity, "cannot share folder!", Toast.LENGTH_SHORT).show();
                                        return;
                                    }
                                    i++;
                                }
                                i = 0;
                                while (i < s_s) {

                                    uri.add(FileProvider.getUriForFile(parent_activity,
                                            "com.hs.efilemanager" + ".provider",
                                            selected.get(i)));
                                    i++;
                                }
                                Intent intent1 = new Intent(Intent.ACTION_SEND_MULTIPLE);
                                intent1.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uri);
                                intent1.setType("*/*");
                                startActivity(intent1);
                            }
                        }

                        @Override
                        public void Option_item_OnlongClickListener(List<File> paramList) {

                        }
                    },
                    easyFileManager.OPTION_SHARE_ID,
                    true, true
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.paste_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (easyFileManager.this.Option_id_being_carried_out.equals("CPY") || easyFileManager.this.Option_id_being_carried_out.equals("MV"))
                    for (File_item file_item : easyFileManager.this.current_directory_FileItem_list_tmp) {
                        if (file_item.is_selected) {
                            File f = new File(file_item.File_parent_path + "/" + file_item.FileName);
                            if (easyFileManager.this.Option_id_being_carried_out.equals("CPY")) {
                                if (f.isDirectory()) {
                                    try {
                                        utils.copy_files(f, new File(easyFileManager.this.current_directory_path));
                                    } catch (Throwable e) {

                                    }
                                }
                                if (f.isFile()) {
                                    try {
                                        utils.copy_file(f, new File(easyFileManager.this.current_directory_path));
                                    } catch (Throwable e) {

                                    }
                                }
                            }
                            if (easyFileManager.this.Option_id_being_carried_out.equals("MV")) {
                                try {
                                    utils.move_files(f, new File(easyFileManager.this.current_directory_path));
                                } catch (Throwable throwable) {

                                }
                            }
//                  try {
//                    easyFileManager.perform_action_on_file_or_folder(new File(file_item.File_parent_path + "/" + file_item.FileName), new File_action_event_listener() {
//                          public void on_File_about_to_be_processed(File f) {
//                            if (f.isDirectory())
//                              (new File(f.getPath().replaceFirst(file_item.File_parent_path, easyFileManager.this.current_directory_path))).mkdir();
//                            if (f.isFile())
//                              easyFileManager.this.copy_File(f, new File(f.getPath().replaceFirst(file_item.File_parent_path, easyFileManager.this.current_directory_path)), easyFileManager.this.Option_id_being_carried_out.equals("MV"));
//                          }
//
//                          public void on_Overall_progress_changed(int amount_of_progress_done, int amount_of_all_the_progress) {
//                            Toast.makeText(easyFileManager.this.context, amount_of_progress_done + "of " + amount_of_all_the_progress + " done", Toast.LENGTH_SHORT)
//                              .show();
//                            if (easyFileManager.this.Option_id_being_carried_out.equals("MV") && amount_of_all_the_progress == amount_of_progress_done)
//                              try {
//                                Process p = Runtime.getRuntime().exec("rm " + file_item.File_parent_path + "/" + file_item.FileName + " -R");
//                                p.waitFor();
//                              } catch (IOException e) {
//                                e.printStackTrace();
//                              } catch (InterruptedException e) {
//                                e.printStackTrace();
//                              }
//                          }
//                        });
//                  } catch (Throwable e) {
//                    e.printStackTrace();
//                  }
                        }
                    }
                easyFileManager.this.set_state(0);
//            Toast.makeText(easyFileManager.this.context, "pasted", Toast.LENGTH_LONG).show();
                easyFileManager.this.load_directory_files(new File((easyFileManager.this.state == STATE_BROWSING_DIRS) ? easyFileManager.this.current_directory_path : easyFileManager.this.current_directory_path_tmp), false);
            }
        });
    }

    private void copy_File(File source, File destination, boolean delete_source) {
        byte[] buffer = new byte[16384];
        try {
            if (!destination.exists())
                destination.createNewFile();
            FileInputStream is = new FileInputStream(source);
            FileOutputStream os = new FileOutputStream(destination);
            int c = is.read(buffer);
            while (c != -1) {
                os.write(buffer, 0, c);
                c = is.read(buffer);
            }
            os.flush();
            os.close();
            is.close();
            if (delete_source)
                source.delete();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void set_state(int state) {
        if (this.state == STATE_BROWSING_DIRS &&
                state == STATE_BROWSING_DIRS_TO_SELECT_COPY_OR_CUT_DESTINATION) {
            this.state = state;
            this.s_s_tmp = this.s_s;
            this.mode = MODE_SINGLE_FILE_SELECTION;
            this.current_directory_FileItem_list_tmp.removeAll(this.current_directory_FileItem_list_tmp);
            this.current_directory_FileItem_list_tmp.addAll(this.current_directory_FileItem_list);
            this.current_directory_path_tmp = this.current_directory_path;
            for (Option_item option_item : this.option_items_list) {
                if (option_item.Option_id.equals("NEW_FOLDER"))
                    continue;
                this.options_bar.findViewById(option_item.view_id).setVisibility(View.GONE);
            }
            load_directory_files(new File(this.SDCARD_Path), false);
            this.paste_button.setVisibility(View.VISIBLE);
        }
        if (this.state == STATE_BROWSING_DIRS_TO_SELECT_COPY_OR_CUT_DESTINATION &&
                state == STATE_BROWSING_DIRS) {
            this.state = state;
            this.s_s = this.s_s_tmp;
            this.mode = MODE_REGULAR_FILE_MANAGMENT;
            this.current_directory_path = this.current_directory_path_tmp;
            this.current_directory_FileItem_list.removeAll(this.current_directory_FileItem_list);
            this.current_directory_FileItem_list.addAll(this.current_directory_FileItem_list_tmp);
            this.current_directory_FileItem_list_tmp.removeAll(this.current_directory_FileItem_list_tmp);
            this.notify_relative_adapter();
            for (Option_item option_item : this.option_items_list)
                this.options_bar.findViewById(option_item.view_id).setVisibility(View.VISIBLE);
            this.path.setText(this.current_directory_path);
            this.paste_button.setVisibility(View.GONE);
            this.recyclerView.scrollToPosition(0);
            File f = new File(this.current_directory_path);
            if (f.getParent() != null) {
                this.tmpaddr0 = f.getParent();
            } else {
                this.tmpaddr0 = "/";
            }
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void reload_current_directory() {
        try {
            navigate_to_directory(new File(get_current_path()));
        } catch (IOException e) {
//      throw new RuntimeException(e);
        }
    }

    private void load_directory_files(File f, boolean scrool_to_last_selected_folder) {
        this.path.setText("/" + f.getPath());
        if (this.state == STATE_BROWSING_DIRS_TO_SELECT_COPY_OR_CUT_DESTINATION)
            this.path.setText("to: " + f.getPath());
        this.s_s = 0;
        if (this.state == STATE_BROWSING_DIRS)
            set_visibility_of_options_that_are_available_only_when_files_are_selected(View.GONE);
        String[] filelist = f.list();
        int j = 0, last_selected_dir_position = 0;
        this.current_directory_FileItem_list.removeAll(this.current_directory_FileItem_list);
        if (filelist != null && filelist.length != 0) {
            Arrays.sort(filelist);
            while (j < filelist.length) {
                if (scrool_to_last_selected_folder && filelist[j].equals((new File(this.current_directory_path)).getName()))
                    last_selected_dir_position = j;
                File_item u = new File_item(filelist[j], f.getPath());
                j++;
                if (!is_file_extension_allowed(new File(u.File_parent_path + "/" + u.FileName)))
                    continue;
                this.current_directory_FileItem_list.add(u);
            }
        }
        if (this.adap != null && this.grid_adap != null)
            this.notify_relative_adapter();
        if (scrool_to_last_selected_folder) {
            this.recyclerView.scrollToPosition(last_selected_dir_position);
        } else {
            this.recyclerView.scrollToPosition(0);
        }
        if (f.getParent() != null) {
            this.tmpaddr0 = f.getParent();
        } else {
            this.tmpaddr0 = "/";
        }
        this.current_directory_path = f.getPath() + "/";
    }

    public void unselect_all_file_items() throws Exception {
        if (this.state == STATE_BROWSING_DIRS_TO_SELECT_COPY_OR_CUT_DESTINATION)
            throw new Exception("Action cannot be performed now.");
        if (this.s_s == 0)
            return;
        for (File_item file_item : this.current_directory_FileItem_list) {
            if (file_item.is_selected)
                file_item.is_selected = false;
        }
        this.s_s = 0;
        set_visibility_of_options_that_are_available_only_when_files_are_selected(8);
        this.notify_relative_adapter();
    }

    public boolean is_file_extension_allowed(File file) {
        if (file.isFile()) {
            if (this.allowed_file_extentions_list.size() > 0) {
                return this.allowed_file_extentions_list.contains(get_FileName_Extention_full(file.getName()));
            } else {
                return !this.excluded_file_extentions_list.contains(get_FileName_Extention_full(file.getName()));
            }
        } else {
            if (this.allowed_folder_extentions_list.size() > 0) {
                return this.allowed_folder_extentions_list.contains(get_FileName_Extention_full(file.getName()));
            } else {
                return !this.excluded_folder_extentions_list.contains(get_FileName_Extention_full(file.getName()));
            }

        }
    }

    public void onStop() {
        super.onStop();
    }

    public void halt_loadings() {
        if (image_loader != null)
            image_loader.halt();
    }

    private void load_image(ImageView icon, int position, File_item record) {
        image_loader.add_task(new Runnable() {
            @Override
            public void run() {
                try {
                    record.File_image_bitmap = utils.image_utils.memory_considering_bitmap.loadLightWeightBitmap(
                            new File(record.File_parent_path + "/" + record.FileName));

                } catch (Throwable t) {
                }
            }
        }, position, new utils.one_threaded_task_handler.task_interface() {
            @Override
            public boolean is_still_relevant(int id) {
//                if(id>=layoutManager.findFirstVisibleItemPosition()&&
//                        id<=layoutManager.findLastVisibleItemPosition())
//                    return true;
                return true;
//                return false;
            }

            @Override
            public void on_task_done(int id) {
//        parent_activity.runOnUiThread(new Runnable() {
//          @Override
//          public void run() {
//            icon.setImageBitmap(record.File_image_bitmap);
//          }
//        });
            }
        });
    }

    public void navigate_to_parent_directory() {
        load_directory_files(new File(this.tmpaddr0), true);
    }

    public void navigate_to_directory(File f) throws IOException {
        if (!f.exists())
            throw new FileNotFoundException();
        if (f.isFile())
            throw new IOException("This file is not a directory!");
        load_directory_files(f, false);
    }

    public List<String> get_list_of_option_IDs() {
        List<String> l = new ArrayList<>();
        for (Option_item option_item : this.option_items_list)
            l.add(option_item.Option_id);
        return l;
    }

    public void show_pic(final File image_File) {
        final Dialog dialog = new Dialog((Context) this.parent_activity);
        dialog.setTitle(image_File.getName());
        dialog.setContentView(R.layout.failed_attempt_dialog_layout);
        (new Thread(new Runnable() {
            public void run() {
                final BitmapFactory.Options options = new BitmapFactory.Options();
                options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                options.inSampleSize = 10;
                while (options.inSampleSize > 2 && !easyFileManager.this.filemanager_exited) {
                    options.inSampleSize--;
                    Bitmap im = BitmapFactory.decodeFile(image_File.getPath(), options);
                    final Bitmap finalIm = im;
                    easyFileManager.this.parent_activity.runOnUiThread(new Runnable() {
                        public void run() {
                            if (dialog.isShowing()) {
                                ((ImageView) dialog.findViewById(R.id.tooken_pic)).setImageBitmap(finalIm);
                            } else {
                                options.inSampleSize = 0;
                            }
                        }
                    });
                }
            }
        })).start();
        dialog.show();
        dialog.findViewById(R.id.delete_but_id).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                image_File.delete();
                easyFileManager.this.notify_relative_adapter();
                Toast.makeText(easyFileManager.this.context, "Image removed", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
    }

    public void add_folder() throws Exception {
        if (this.context == null)
            throw new Exception("FileManager Fragment is not yet initiated by system. check FileManager_is_ready before calling this method.");
        final Dialog dialog = new Dialog((Context) this.parent_activity);
        dialog.show();
        dialog.getWindow().addFlags(1);
        dialog.getWindow().setLayout(-1, -2);
        dialog.setContentView(R.layout.add_folder);
        dialog.findViewById(R.id.create_butt_id).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String name = ((EditText) dialog.findViewById(R.id.file_name_edittext_id)).getText().toString();
                if (name.length() > 0) {
                    File f = easyFileManager.return_nonexisting_file(easyFileManager.this.current_directory_path, name, "");
                    f.mkdir();
                    easyFileManager.this.load_directory_files(new File(easyFileManager.this.current_directory_path), false);
                    dialog.dismiss();
                } else {
                    Toast.makeText(easyFileManager.this.context, "Enter The File Name", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void add_Option_to_OptionsBar(Bitmap option_icon_bitmap, final Option_item_events_listener option_item_events_listener, String Option_ID, boolean is_available_only_when_files_are_selected, boolean is_conditional) throws Exception {
        if (this.options_bar == null)
            throw new Exception("FileManager Fragment is not yet initiated by system. check FileManager_is_ready before calling this method.");
        if (this.state == STATE_BROWSING_DIRS_TO_SELECT_COPY_OR_CUT_DESTINATION)
            throw new Exception("Action cannot be performed now.");
        if (option_icon_bitmap == null)
            throw new Exception("option_icon_bitmap cannot be null");
        if (option_item_events_listener == null)
            throw new Exception("option_item_events_listener cannot be null");
        if (Option_ID == null || Option_ID.length() == 0)
            throw new Exception("Option_ID cannot be null");
        if (option_icon_bitmap == null)
            throw new Exception("option_icon_bitmap cannot be null");
        Option_item option_item = null;
        int i = 0;
        while (i < this.option_items_list.size()) {
            Option_item optionItem = this.option_items_list.get(i);
            if (optionItem.Option_id.equals(Option_ID)) {
                option_item = optionItem;
                this.option_items_list.remove(i);
                break;
            }
            i++;
        }
        if (option_item != null) {
            this.options_bar.removeView(this.options_bar.findViewById(option_item.view_id));
            if (is_conditional) {
                option_item.option_item_events_listener_conditional_option =
                        (Option_item_events_listener_with_processor) option_item_events_listener;
                option_item.is_conditional_option = true;
                option_item.is_available_only_when_files_are_selected = true;
            } else {
                option_item.option_item_events_listener = option_item_events_listener;
                option_item.is_conditional_option = false;
                option_item.is_available_only_when_files_are_selected = is_available_only_when_files_are_selected;
            }
            option_item.icon_bitmap = option_icon_bitmap;
        } else {
            if (is_conditional) {
                option_item = new Option_item(option_icon_bitmap,
                        (Option_item_events_listener_with_processor) option_item_events_listener, Option_ID);
            } else
                option_item = new Option_item(option_icon_bitmap,
                        option_item_events_listener, Option_ID, is_available_only_when_files_are_selected);
            option_item.view_id = ViewCompat.generateViewId();
        }

        option_item.cont = (ConstraintLayout) parent_activity.getLayoutInflater().inflate(R.layout.option_item, null);
        option_item.button = (CustomImageButton) option_item.cont.getChildAt(0);
        option_item.cont.setId(option_item.view_id);

        ImageButton imageButton = option_item.button;
        UI_config.option_icon.Option_icon_height = ViewGroup.LayoutParams.MATCH_PARENT;
        UI_config.option_icon.Option_icon_width = ViewGroup.LayoutParams.WRAP_CONTENT;
        LinearLayout.LayoutParams layoutParams =
                new LinearLayout.LayoutParams(UI_config.option_icon.Option_icon_width,
                        UI_config.option_icon.Option_icon_height);
        int marginInDp = 3;
        int marginInPixels = (int) (marginInDp * getResources().getDisplayMetrics().density);
        layoutParams.setMargins(marginInPixels, marginInPixels, marginInPixels, marginInPixels);
        imageButton.setLayoutParams(layoutParams);
//    imageButton.setId(option_item.view_id);
        imageButton.setImageBitmap(option_item.icon_bitmap);
//    imageButton.setBackgroundColor(Color.TRANSPARENT);
        imageButton.setAdjustViewBounds(true);
        imageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                option_item_events_listener.Option_item_OnClickListener(easyFileManager.this.get_selected_Files_list());
            }
        });
        imageButton.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {
                option_item_events_listener.Option_item_OnlongClickListener(easyFileManager.this.get_selected_Files_list());
                return false;
            }
        });


        this.options_bar.addView(option_item.cont);
        if (this.s_s == 0 && is_available_only_when_files_are_selected)
            this.options_bar.findViewById(option_item.view_id).setVisibility(View.GONE);
        this.option_items_list.add(option_item);
    }

    public void add_Option_to_OptionsBar(int resource_drawable_id, final Option_item_events_listener option_item_events_listener, String Option_ID, boolean is_available_only_when_files_are_selected, boolean is_conditional) throws Exception {
        if (this.options_bar == null)
            throw new Exception("FileManager Fragment is not yet initiated by system. check FileManager_is_ready before calling this method.");
        if (this.state == STATE_BROWSING_DIRS_TO_SELECT_COPY_OR_CUT_DESTINATION)
            throw new Exception("Action cannot be performed now.");
        if (option_item_events_listener == null)
            throw new Exception("option_item_events_listener cannot be null");
        if (Option_ID == null || Option_ID.length() == 0)
            throw new Exception("Option_ID cannot be null");
        Option_item option_item = null;
        int i = 0;
        while (i < this.option_items_list.size()) {
            Option_item optionItem = this.option_items_list.get(i);
            if (optionItem.Option_id.equals(Option_ID)) {
                option_item = optionItem;
                this.option_items_list.remove(i);
                break;
            }
            i++;
        }
        if (option_item != null) {
            this.options_bar.removeView(this.options_bar.findViewById(option_item.view_id));
            if (is_conditional) {
                option_item.option_item_events_listener_conditional_option =
                        (Option_item_events_listener_with_processor) option_item_events_listener;
                option_item.is_conditional_option = true;
                option_item.is_available_only_when_files_are_selected = true;
            } else {
                option_item.option_item_events_listener = option_item_events_listener;
                option_item.is_conditional_option = false;
                option_item.is_available_only_when_files_are_selected = is_available_only_when_files_are_selected;
            }
            option_item.icon_drawable = resource_drawable_id;
        } else {
            if (is_conditional) {
                option_item = new Option_item(resource_drawable_id,
                        (Option_item_events_listener_with_processor) option_item_events_listener, Option_ID);
            } else
                option_item = new Option_item(resource_drawable_id,
                        option_item_events_listener, Option_ID, is_available_only_when_files_are_selected);
            option_item.view_id = ViewCompat.generateViewId();
        }

        option_item.cont = (ConstraintLayout) parent_activity.getLayoutInflater().inflate(R.layout.option_item, null);
        option_item.cont.setLayoutParams(new LinearLayoutCompat.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        option_item.button = (CustomImageButton) option_item.cont.getChildAt(0);
        option_item.cont.setId(option_item.view_id);

        ImageButton imageButton = option_item.button;
        Drawable drawable = getResources().getDrawable(resource_drawable_id);
        imageButton.setImageDrawable(drawable);
        float aspect_ratio = (float) drawable.getIntrinsicWidth() / drawable.getIntrinsicHeight();
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
        layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT;
        layoutParams.width = (int) (layoutParams.height * aspect_ratio);
        int marginInDp = 3;
        int marginInPixels = (int) (marginInDp * getResources().getDisplayMetrics().density);
        layoutParams.setMargins(marginInPixels, marginInPixels, marginInPixels, marginInPixels);

//    imageButton.setId(option_item.view_id);
//    imageButton.setBackgroundColor(Color.TRANSPARENT);
        imageButton.setAdjustViewBounds(true);
        imageButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                option_item_events_listener.Option_item_OnClickListener(easyFileManager.this.get_selected_Files_list());
            }
        });
        imageButton.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View view) {
                option_item_events_listener.Option_item_OnlongClickListener(easyFileManager.this.get_selected_Files_list());
                return false;
            }
        });

        this.options_bar.addView(option_item.cont);
        if (this.s_s == 0 && is_available_only_when_files_are_selected)
            this.options_bar.findViewById(option_item.view_id).setVisibility(View.GONE);
        this.option_items_list.add(option_item);
    }

    public Option_item get_option_by_optionID(String option_id) {
        int i = 0;
        while (i < this.option_items_list.size()) {
            if (this.option_items_list.get(i).Option_id.equals(option_id))
                return this.option_items_list.get(i);
            i++;
        }
        return null;
    }

    private void set_visibility_of_options_that_are_available_only_when_files_are_selected(int visibility) {
        for (Option_item option_item : this.option_items_list) {
            if (option_item.is_available_only_when_files_are_selected)
                if (option_item.is_conditional_option) {
                    if (visibility == View.GONE)
                        this.options_bar.findViewById(option_item.view_id).setVisibility(visibility);
                    else if (option_item.option_item_events_listener_conditional_option.check_file_list(get_selected_Files_list())) {
                        this.options_bar.findViewById(option_item.view_id).setVisibility(visibility);
                    } else {
                        this.options_bar.findViewById(option_item.view_id).setVisibility(View.GONE);
                    }
                } else
                    this.options_bar.findViewById(option_item.view_id).setVisibility(visibility);
        }

    }

    public void remove_Option_from_OptionsBar(String Option_ID) throws Exception {
        if (this.options_bar == null)
            throw new Exception("FileManager Fragment is not yet initiated by system. check FileManager_is_ready before calling this method.");
        int i = 0;
        Option_item option_item = null;
        while (i < this.option_items_list.size()) {
            Option_item optionItem = this.option_items_list.get(i);
            if (optionItem.Option_id.equals(Option_ID)) {
                option_item = optionItem;
                this.option_items_list.remove(i);
                break;
            }
            i++;
        }
        if (option_item != null) {
            this.options_bar.removeView(this.options_bar.findViewById(option_item.view_id));
        } else {
            throw new Exception("no option with such ID found.");
        }
    }

    public String get_current_path() {
        return (this.state == STATE_BROWSING_DIRS) ? this.current_directory_path : this.current_directory_path_tmp;
    }

    public List<File> get_selected_Files_list() {
        fileList.removeAll(fileList);
        if (this.current_directory_FileItem_list.size() > 0) {
            int i = 0;
            for (File_item file_item : this.current_directory_FileItem_list) {
                if (file_item.is_selected)
                    fileList.add(new File(file_item.File_parent_path + "/" + file_item.FileName));
            }
        }
        return fileList;
    }

    public void handle_Back_button_pressed_event() {
        if (this.state == STATE_BROWSING_DIRS)
            if (this.s_s > 0) {
                try {
                    unselect_all_file_items();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                if (this.current_directory_path.equals("/sdcard/")) {
                    this.fileManager_states_listener.onFile_manager_backpressed_on_root_dir();
                }
                navigate_to_parent_directory();
            }
        if (this.state == STATE_BROWSING_DIRS_TO_SELECT_COPY_OR_CUT_DESTINATION)
            if (this.current_directory_path.equals("//")) {
                set_state(STATE_BROWSING_DIRS);
            } else {
                navigate_to_parent_directory();
            }
    }

    public void show_OptionsBar(boolean b) {
        this.options_bar_is_visible = b;
        if (b) {
            if (this.optionsBar_scroolview != null)
                this.optionsBar_scroolview.setVisibility(View.VISIBLE);
        } else if (this.optionsBar_scroolview != null) {
            this.optionsBar_scroolview.setVisibility(View.GONE);
        }
    }

    public void onDestroy() {
        super.onDestroy();
        this.filemanager_exited = true;
        this.dataset_refresher.cancel();
    }

    private static class UI_config {
        public static class option_icon {
            public static int Option_icon_width = 0;
            public static int Option_icon_height = 0;
        }
    }

    private static class folder_struc {
        public int pointer = 0;

        public int lenght;

        public String[] list;

        public folder_struc(String[] l) {
            this.list = l;
            this.lenght = this.list.length;
        }
    }

    private class Option_item {
        public boolean is_available_only_when_files_are_selected = false, is_conditional_option;
        public Bitmap icon_bitmap;
        public int icon_drawable;

        public Option_item_events_listener option_item_events_listener;
        public Option_item_events_listener_with_processor option_item_events_listener_conditional_option;

        public String Option_id;

        public int view_id;
        public ConstraintLayout cont;
        public CustomImageButton button;

        public Option_item(Bitmap option_icon_bitmap, Option_item_events_listener option_item_events_listener, String Option_ID, boolean is_available_only_when_files_are_selected) {
            this.icon_bitmap = option_icon_bitmap;
            this.is_available_only_when_files_are_selected = is_available_only_when_files_are_selected;
            this.option_item_events_listener = option_item_events_listener;
            this.Option_id = Option_ID;
        }

        public Option_item(Bitmap option_icon_bitmap, Option_item_events_listener_with_processor option_item_events_listener, String Option_ID) {
            this.icon_bitmap = option_icon_bitmap;
            is_conditional_option = true;
            this.is_available_only_when_files_are_selected = true;
            this.option_item_events_listener_conditional_option = option_item_events_listener;
            this.Option_id = Option_ID;
        }

        public Option_item(int option_icon_resource, Option_item_events_listener option_item_events_listener, String Option_ID, boolean is_available_only_when_files_are_selected) {
            this.icon_drawable = option_icon_resource;
            this.is_available_only_when_files_are_selected = is_available_only_when_files_are_selected;
            this.option_item_events_listener = option_item_events_listener;
            this.Option_id = Option_ID;
        }

        public Option_item(int option_icon_resource, Option_item_events_listener_with_processor option_item_events_listener, String Option_ID) {
            this.icon_drawable = option_icon_resource;
            is_conditional_option = true;
            this.is_available_only_when_files_are_selected = true;
            this.option_item_events_listener_conditional_option = option_item_events_listener;
            this.Option_id = Option_ID;
        }

        public void make_icon_blink() {
            int p_color;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    parent_activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Option_item.this.cont.setBackgroundColor(Color.BLUE);
                        }
                    });
                    try {
                        Thread.sleep(800);
                    } catch (InterruptedException e) {

                    }
                    parent_activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Option_item.this.cont.setBackgroundColor(Color.WHITE);
                        }
                    });
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {

                    }
                    parent_activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Option_item.this.cont.setBackgroundColor(Color.BLUE);
                        }
                    });
                    try {
                        Thread.sleep(900);
                    } catch (InterruptedException e) {

                    }
                    parent_activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Option_item.this.cont.setBackgroundColor(Color.WHITE);
                        }
                    });
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {

                    }
                    parent_activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Option_item.this.cont.setBackgroundColor(Color.BLUE);
                        }
                    });
                    try {
                        Thread.sleep(900);
                    } catch (InterruptedException e) {

                    }
                    parent_activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Option_item.this.cont.setBackgroundColor(
                                    parent_activity.getResources().getColor(R.color.filemanager_option_default)
                            );
                        }
                    });
                }
            }).start();
//      this.button.setBackgroundColor(Color.BLUE);
        }

        public void set_icon_background_to_seen_notification() {
            this.button.setBackgroundColor(Color.WHITE);
        }
    }

    //  public void  set_option_notification_color_to_seen(String Option_id){
//    for (Option_item item :option_items_list){
//      if(item.Option_id.equals(Option_id)){
//        item.set_icon_background_to_seen_notification();
//        return;
//      }
//    }
//  }
    private class extention_icon {
        public String extention;

        public Bitmap icon;
        public Drawable drawable;

        public extention_icon(Bitmap icon, String extention) {
            this.extention = extention;
            this.icon = icon;
        }

        public extention_icon(Drawable icon, String extention) {
            this.extention = extention;
            this.drawable = icon;
        }
    }

    public class grid_fileadapter extends RecyclerView.Adapter<grid_fileadapter.fileholder> {
        private final Thread Image_nulling_thread = new Thread(new Runnable() {
            public void run() {
                int i = 0, temp = easyFileManager.this.adap.recyclerview_middle_item_adapter_position;
                while (!easyFileManager.this.filemanager_exited) {
                    try {
                        if (easyFileManager.this.current_directory_FileItem_list.size() != 0 &&
                                temp != easyFileManager.this.adap.recyclerview_middle_item_adapter_position)
                            i = temp = easyFileManager.this.adap.recyclerview_middle_item_adapter_position;
                        if (easyFileManager.this.current_directory_FileItem_list.size() != 0 && i >= 0 && i < easyFileManager.this.current_directory_FileItem_list.size() && (
                                i < temp - 80 || i > temp + 80))
                            if (easyFileManager.this.current_directory_FileItem_list.get(i) != null)
                                (easyFileManager.this.current_directory_FileItem_list.get(i)).File_image_bitmap = null;
                        if (i >= easyFileManager.this.current_directory_FileItem_list.size())
                            i = 0;
                    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {

                    } catch (NullPointerException nullPointerException) {
                    }
                    i++;
                }
            }
        });
        private File file = Environment.getRootDirectory();
        private int recyclerview_middle_item_adapter_position = 0;
        private final Thread Image_loading_thread = new Thread(new Runnable() {
            public void run() {
                while (!easyFileManager.this.filemanager_exited) {
                    int temp_position = grid_fileadapter.this.recyclerview_middle_item_adapter_position;
                    int i = 0;
                    while (i <= 80 && !easyFileManager.this.filemanager_exited && temp_position == easyFileManager.this.adap.recyclerview_middle_item_adapter_position) {
                        try {
                            if (i + temp_position < easyFileManager.this.current_directory_FileItem_list.size() &&
                                    easyFileManager.this.current_directory_FileItem_list.size() != 0 &&
                                    easyFileManager.this.current_directory_FileItem_list.get(temp_position + i) != null &&
                                    (easyFileManager.this.current_directory_FileItem_list.get(temp_position + i)).File_image_bitmap == null)
                                ((File_item) easyFileManager.this.current_directory_FileItem_list.get(temp_position + i)).load_image_bitmap();
                            if (-i + temp_position >= 0 &&
                                    easyFileManager.this.current_directory_FileItem_list.size() != 0 &&
                                    easyFileManager.this.current_directory_FileItem_list.get(temp_position - i) != null &&
                                    (easyFileManager.this.current_directory_FileItem_list.get(temp_position - i)).File_image_bitmap == null)
                                ((File_item) easyFileManager.this.current_directory_FileItem_list.get(temp_position - i)).load_image_bitmap();
                        } catch (IndexOutOfBoundsException e) {
                            break;
                        } catch (NullPointerException e) {
                            break;
                        }
                        i++;
                    }
                }
            }
        });

        @Override
        public long getItemId(int i) {
            return i;
        }

        public fileholder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemview = LayoutInflater.from(parent.getContext()).inflate(R.layout.rec_grid, parent, false);
            return new fileholder(itemview);
        }

        @Override
        public void onBindViewHolder(@NonNull grid_fileadapter.fileholder holder, int position) {

            if (!this.Image_loading_thread.isAlive())
                this.Image_loading_thread.start();
            if (!this.Image_nulling_thread.isAlive())
                this.Image_nulling_thread.start();
            if (easyFileManager.this.layoutManager.getChildAt(0) != null) {
                this.recyclerview_middle_item_adapter_position =
                        easyFileManager.this.recyclerView.getChildAdapterPosition(easyFileManager.this.layoutManager.getChildAt(0)) + easyFileManager.this.recyclerView.getChildAdapterPosition(easyFileManager.this.layoutManager.getChildAt(easyFileManager.this.layoutManager.getChildCount() - 1));
                this.recyclerview_middle_item_adapter_position /= 2;
            } else {
                this.recyclerview_middle_item_adapter_position = holder.getAdapterPosition();
            }
            File_item file_item = easyFileManager.this.current_directory_FileItem_list.get(position);

            swich_ch(holder, position, true);
            holder.text1.setText(String.valueOf(file_item.FileName));
            this.file = new File(easyFileManager.this.current_directory_path + holder.text1.getText());
            holder.icon.setImageResource(R.drawable.file_document_outline);
            holder.fi = this.file;
            if (this.file.isFile()) {
                String type = easyFileManager.getFileType(this.file);
                String ext = easyFileManager.get_FileName_Extention(this.file.getName());
                if (type != null && type.contains("image") && file_item.File_image_bitmap != null)
                    holder.icon.setImageBitmap(file_item.File_image_bitmap);
//        if (type != null && type.contains("image") ){
//          if(file_item.File_image_bitmap == null) {
//            load_image(holder.icon, position, file_item);
//          }else{
//            holder.icon.setImageBitmap(file_item.File_image_bitmap);
//          }
//        }

                for (easyFileManager.extention_icon extention_icon : easyFileManager.this.icons_and_extentions_list) {
                    if (extention_icon.extention.equals(ext)) {
                        if (extention_icon.drawable != null)
                            holder.icon.setImageDrawable(extention_icon.drawable);
                        else
                            holder.icon.setImageBitmap(extention_icon.icon);
                        break;
                    }
                }
                if (holder.icon.getDrawable() == null)
                    holder.icon.setImageResource(R.drawable.file_document_outline);
            }
            if (this.file.isDirectory())
                holder.icon.setImageResource(R.drawable.folder_outline);
            holder.recy.findViewById(R.id.recy).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    grid_fileadapter.this.file = new File(easyFileManager.this.current_directory_path + holder.text1.getText());
                    if (easyFileManager.this.file_item_events_listener != null)
                        easyFileManager.this.file_item_events_listener.FileItem_onClickListener(grid_fileadapter.this.file);
                    if (easyFileManager.this.mode == MODE_SINGLE_FILE_SELECTION &&
                            grid_fileadapter.this.file.isDirectory()) {
                        easyFileManager.this.tmpaddr0 = grid_fileadapter.this.file.getParent();
                        easyFileManager.this.current_directory_path = grid_fileadapter.this.file.getAbsolutePath() + "/";
                        easyFileManager.this.load_directory_files(grid_fileadapter.this.file, false);
                        grid_fileadapter.this.notifyDataSetChanged();
                    }
                    if (easyFileManager.this.mode == MODE_REGULAR_FILE_MANAGMENT)
                        if (easyFileManager.this.s_s == 0) {
                            if (grid_fileadapter.this.file.isDirectory()) {
                                easyFileManager.this.tmpaddr0 = grid_fileadapter.this.file.getParent();
                                easyFileManager.this.current_directory_path = grid_fileadapter.this.file.getAbsolutePath() + "/";
                                easyFileManager.this.load_directory_files(grid_fileadapter.this.file, false);
                                grid_fileadapter.this.notifyDataSetChanged();
                            }
                        } else {
                            ((File_item) easyFileManager.this.current_directory_FileItem_list.get(position)).switch_selection_status();
                            grid_fileadapter.this.swich_ch(holder, position, false);
                        }
                }
            });
            holder.recy.findViewById(R.id.recy).setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) {
                    grid_fileadapter.this.file = new File(easyFileManager.this.current_directory_path + holder.text1.getText());
                    if (easyFileManager.this.file_item_events_listener != null)
                        easyFileManager.this.file_item_events_listener.FileItem_onLongClickListener(grid_fileadapter.this.file);
                    if (easyFileManager.this.mode == MODE_SINGLE_FILE_SELECTION)
                        return true;
                    if (easyFileManager.this.mode == MODE_REGULAR_FILE_MANAGMENT) {
                        ((File_item) easyFileManager.this.current_directory_FileItem_list.get(position)).switch_selection_status();
                        grid_fileadapter.this.swich_ch(holder, position, false);
                    }
                    return true;
                }
            });
        }

        public int getItemCount() {
            return easyFileManager.this.current_directory_FileItem_list.size();
        }

        private void swich_ch(fileholder holder, int position, boolean f_v) {
            if ((easyFileManager.this.current_directory_FileItem_list.get(position)).is_selected) {
                holder.text1.setBackgroundColor(easyFileManager.this.context.getResources().getColor(R.color.selected));
                holder.recy.findViewById(R.id.recy).setBackgroundColor(easyFileManager.this.context.getResources().getColor(R.color.selected));
                if (!f_v) {
                    easyFileManager.this.s_s++;
                    if (easyFileManager.this.mode == 2)
                        mode_2_pos = position;
                }
            } else {
                holder.text1.setBackgroundColor(easyFileManager.this.context.getResources().getColor(R.color.filemanager_grid_item_default));
                holder.recy.findViewById(R.id.recy).setBackgroundColor(easyFileManager.this.context.getResources().getColor(R.color.filemanager_grid_item_default));
                if (!f_v) {
                    easyFileManager.this.s_s--;
                    if (easyFileManager.this.mode == 2)
                        mode_2_pos = -1;
                }
            }
            if (easyFileManager.this.state == STATE_BROWSING_DIRS) {
                if (last_s_s != s_s) {
                    if (easyFileManager.this.s_s == 0)
                        easyFileManager.this.set_visibility_of_options_that_are_available_only_when_files_are_selected(8);
                    if (easyFileManager.this.s_s > 0)
                        easyFileManager.this.set_visibility_of_options_that_are_available_only_when_files_are_selected(0);
                    last_s_s = s_s;
                }
            }
        }

        public class fileholder extends RecyclerView.ViewHolder {
            public TextView text1;

            public ImageView icon;

            public File fi;

            public LinearLayout recy;

            public fileholder(View view) {
                super(view);
                this.recy = (LinearLayout) view;
                this.text1 = (TextView) view.findViewById(R.id.textV1);
                this.icon = (ImageView) view.findViewById(R.id.icon);
            }
        }
    }

    public class fileadapter extends RecyclerView.Adapter<fileadapter.fileholder> {
        private File file = Environment.getRootDirectory();

        private int recyclerview_middle_item_adapter_position = 0;

        private final Thread Image_loading_thread = new Thread(new Runnable() {
            public void run() {
                while (!easyFileManager.this.filemanager_exited) {
                    int temp_position = fileadapter.this.recyclerview_middle_item_adapter_position;
                    int i = 0;
                    while (i <= 80 && !easyFileManager.this.filemanager_exited && temp_position == easyFileManager.this.adap.recyclerview_middle_item_adapter_position) {
                        try {
                            if (i + temp_position < easyFileManager.this.current_directory_FileItem_list.size() &&
                                    easyFileManager.this.current_directory_FileItem_list.size() != 0 &&
                                    easyFileManager.this.current_directory_FileItem_list.get(temp_position + i) != null &&
                                    (easyFileManager.this.current_directory_FileItem_list.get(temp_position + i)).File_image_bitmap == null)
                                ((File_item) easyFileManager.this.current_directory_FileItem_list.get(temp_position + i)).load_image_bitmap();
                            if (-i + temp_position >= 0 &&
                                    easyFileManager.this.current_directory_FileItem_list.size() != 0 &&
                                    easyFileManager.this.current_directory_FileItem_list.get(temp_position - i) != null &&
                                    (easyFileManager.this.current_directory_FileItem_list.get(temp_position - i)).File_image_bitmap == null)
                                ((File_item) easyFileManager.this.current_directory_FileItem_list.get(temp_position - i)).load_image_bitmap();
                        } catch (IndexOutOfBoundsException e) {
                            break;
                        } catch (NullPointerException e) {
                            break;
                        }
                        i++;
                    }
                }
            }
        });

        private final Thread Image_nulling_thread = new Thread(new Runnable() {
            public void run() {
                int i = 0, temp = easyFileManager.this.adap.recyclerview_middle_item_adapter_position;
                while (!easyFileManager.this.filemanager_exited) {
                    try {
                        if (easyFileManager.this.current_directory_FileItem_list.size() != 0 &&
                                temp != easyFileManager.this.adap.recyclerview_middle_item_adapter_position)
                            i = temp = easyFileManager.this.adap.recyclerview_middle_item_adapter_position;
                        if (easyFileManager.this.current_directory_FileItem_list.size() != 0 && i >= 0 && i < easyFileManager.this.current_directory_FileItem_list.size() && (
                                i < temp - 80 || i > temp + 80))
                            if (easyFileManager.this.current_directory_FileItem_list.get(i) != null)
                                (easyFileManager.this.current_directory_FileItem_list.get(i)).File_image_bitmap = null;
                        if (i >= easyFileManager.this.current_directory_FileItem_list.size())
                            i = 0;
                    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {

                    } catch (NullPointerException nullPointerException) {
                    }
                    i++;
                }
            }
        });

        public fileholder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemview = LayoutInflater.from(parent.getContext()).inflate(R.layout.recm, parent, false);
            return new fileholder(itemview);
        }

        public void onBindViewHolder(final fileholder holder, final int position) {
            if (!this.Image_loading_thread.isAlive())
                this.Image_loading_thread.start();
            if (!this.Image_nulling_thread.isAlive())
                this.Image_nulling_thread.start();
            if (easyFileManager.this.layoutManager.getChildAt(0) != null) {
                this.recyclerview_middle_item_adapter_position =
                        easyFileManager.this.recyclerView.getChildAdapterPosition(easyFileManager.this.layoutManager.getChildAt(0)) + easyFileManager.this.recyclerView.getChildAdapterPosition(easyFileManager.this.layoutManager.getChildAt(easyFileManager.this.layoutManager.getChildCount() - 1));
                this.recyclerview_middle_item_adapter_position /= 2;
            } else {
                this.recyclerview_middle_item_adapter_position = holder.getAdapterPosition();
            }
            File_item file_item = easyFileManager.this.current_directory_FileItem_list.get(position);
            swich_ch(holder, position, true);
            holder.text1.setText(String.valueOf(file_item.FileName));
            this.file = new File(easyFileManager.this.current_directory_path + holder.text1.getText());
            holder.icon.setImageResource(R.drawable.file_document_outline);
            holder.fi = this.file;
            if (this.file.isFile()) {
                String type = easyFileManager.getFileType(this.file);
                String ext = easyFileManager.get_FileName_Extention(this.file.getName());
                if (type != null && type.contains("image") && file_item.File_image_bitmap != null)
                    holder.icon.setImageBitmap(file_item.File_image_bitmap);
//        if (type != null && type.contains("image") && file_item.File_image_bitmap == null)
//          load_image(holder.icon,position,file_item);
                for (easyFileManager.extention_icon extention_icon : easyFileManager.this.icons_and_extentions_list) {
                    if (extention_icon.extention.equals(ext)) {
                        if (extention_icon.drawable != null)
                            holder.icon.setImageDrawable(extention_icon.drawable);
                        else
                            holder.icon.setImageBitmap(extention_icon.icon);
                        break;
                    }
                }
                if (holder.icon.getDrawable() == null)
                    holder.icon.setImageResource(R.drawable.file_document_outline);
            }
            if (this.file.isDirectory())
                holder.icon.setImageResource(R.drawable.folder_outline);
            holder.recy.findViewById(R.id.recy).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    fileadapter.this.file = new File(easyFileManager.this.current_directory_path + holder.text1.getText());
                    if (easyFileManager.this.file_item_events_listener != null)
                        easyFileManager.this.file_item_events_listener.FileItem_onClickListener(fileadapter.this.file);
                    if (easyFileManager.this.mode == MODE_SINGLE_FILE_SELECTION &&
                            fileadapter.this.file.isDirectory()) {
                        easyFileManager.this.tmpaddr0 = fileadapter.this.file.getParent();
                        easyFileManager.this.current_directory_path = fileadapter.this.file.getAbsolutePath() + "/";
                        easyFileManager.this.load_directory_files(fileadapter.this.file, false);
                        fileadapter.this.notifyDataSetChanged();
                    }
                    if (easyFileManager.this.mode == MODE_REGULAR_FILE_MANAGMENT)
                        if (easyFileManager.this.s_s == 0) {
                            if (fileadapter.this.file.isDirectory()) {
                                easyFileManager.this.tmpaddr0 = fileadapter.this.file.getParent();
                                easyFileManager.this.current_directory_path = fileadapter.this.file.getAbsolutePath() + "/";
                                easyFileManager.this.load_directory_files(fileadapter.this.file, false);
                                fileadapter.this.notifyDataSetChanged();
                            }
                        } else {
                            ((File_item) easyFileManager.this.current_directory_FileItem_list.get(position)).switch_selection_status();
                            fileadapter.this.swich_ch(holder, position, false);
                        }
                }
            });
            holder.recy.findViewById(R.id.recy).setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) {
                    fileadapter.this.file = new File(easyFileManager.this.current_directory_path + holder.text1.getText());
                    if (easyFileManager.this.file_item_events_listener != null)
                        easyFileManager.this.file_item_events_listener.FileItem_onLongClickListener(fileadapter.this.file);
                    if (easyFileManager.this.mode == MODE_SINGLE_FILE_SELECTION)
                        return true;
                    if (easyFileManager.this.mode == MODE_REGULAR_FILE_MANAGMENT) {
                        ((File_item) easyFileManager.this.current_directory_FileItem_list.get(position)).switch_selection_status();
                        fileadapter.this.swich_ch(holder, position, false);
                    }
                    return true;
                }
            });
        }

        public int getItemCount() {
            return easyFileManager.this.current_directory_FileItem_list.size();
        }

        private void swich_ch(fileholder holder, int position, boolean f_v) {
            if ((easyFileManager.this.current_directory_FileItem_list.get(position)).is_selected) {
                holder.text1.setBackgroundColor(easyFileManager.this.context.getResources().getColor(R.color.selected));
                holder.recy.findViewById(R.id.recy).setBackgroundColor(easyFileManager.this.context.getResources().getColor(R.color.selected));
                if (!f_v) {
                    easyFileManager.this.s_s++;
                    if (easyFileManager.this.mode == 2)
                        mode_2_pos = position;
                }
            } else {
                holder.text1.setBackgroundColor(easyFileManager.this.context.getResources().getColor(R.color.default1));
                holder.recy.findViewById(R.id.recy).setBackgroundColor(easyFileManager.this.context.getResources().getColor(R.color.default1));
                if (!f_v) {
                    easyFileManager.this.s_s--;
                    if (easyFileManager.this.mode == 2)
                        mode_2_pos = -1;
                }
            }
            if (easyFileManager.this.state == STATE_BROWSING_DIRS) {
                if (last_s_s != s_s) {
                    if (easyFileManager.this.s_s == 0)
                        easyFileManager.this.set_visibility_of_options_that_are_available_only_when_files_are_selected(8);
                    if (easyFileManager.this.s_s > 0)
                        easyFileManager.this.set_visibility_of_options_that_are_available_only_when_files_are_selected(0);
                    last_s_s = s_s;
                }
            }
        }

        public class fileholder extends RecyclerView.ViewHolder {
            public TextView text1;

            public ImageView icon;

            public File fi;

            public LinearLayout recy;

            public fileholder(View view) {
                super(view);
                this.recy = (LinearLayout) view;
                this.text1 = (TextView) view.findViewById(R.id.textV1);
                this.icon = (ImageView) view.findViewById(R.id.icon);
            }
        }
    }
}
