package com.hoshmandsakht.efm;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class yes_no_dialog {
    public interface simple_yes_no_interface {
        public void on_value_submitted(boolean decision);
    }
    public static void input(Context context, simple_yes_no_interface syoi, String question, String button_value_positive, String button_value_negative) {
        final Dialog dialog = new Dialog(context);
        dialog.show();
        dialog.getWindow().addFlags(1);
        dialog.getWindow().setLayout(-1, -2);
        dialog.setContentView(R.layout.yes_no_layout);
        ((Button)dialog.findViewById(R.id.buttonYes)).setText(button_value_positive);
        ((Button)dialog.findViewById(R.id.buttonNo)).setText(button_value_negative);
        ((TextView)dialog.findViewById(R.id.explanationText)).setText(question);
        dialog.findViewById(R.id.buttonYes).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                syoi.on_value_submitted(true);
                dialog.dismiss();
            }
        });
        dialog.findViewById(R.id.buttonNo).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                syoi.on_value_submitted(false);
                dialog.dismiss();
            }
        });
    }
}
